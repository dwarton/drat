//functions for allClasses class
#include"rcp4.h"

allClasses::allClasses(){};
allClasses::~allClasses(){};
