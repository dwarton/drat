//functions for sam_all_classes class
#include"sam_cpp2.h"

sam_cpp_all_classes::sam_cpp_all_classes(){};
sam_cpp_all_classes::~sam_cpp_all_classes(){};
