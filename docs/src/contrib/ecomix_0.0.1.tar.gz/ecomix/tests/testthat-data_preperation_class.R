library(testthat)
test_check("ecomix",filter='data_preperation_class')
