library(testthat)
test_check("ecomix",filter='SAM_frontend')
