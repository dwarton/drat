library(testthat)
library(ecomix)
test_check("ecomix",filter='SAM_partial_bernoulli')

