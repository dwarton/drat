library(testthat)
test_check("ecomix",filter='RCP_frontend')
