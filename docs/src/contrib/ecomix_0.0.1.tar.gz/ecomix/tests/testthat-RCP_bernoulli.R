library(testthat)
test_check("ecomix",filter='RCP_bernoulli')
