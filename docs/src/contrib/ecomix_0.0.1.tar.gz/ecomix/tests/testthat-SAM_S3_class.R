library(testthat)
test_check("ecomix",filter='SAM_S3_class')
